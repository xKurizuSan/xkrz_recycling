Config = {}

Config.Reward = {
    ItemList = {
        "metalscrap", "plastic", "copper", "glass", "rubber", "aluminum"
    }
}